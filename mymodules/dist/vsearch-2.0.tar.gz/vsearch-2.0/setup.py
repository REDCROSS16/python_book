from setuptools import setup

setup(
    name = 'vsearch',
    version = '2.0',
    description = 'функции поиска',
    author = 'ALEX RED',
    author_email = 'belkill@mail.ru',
    url = 'https://github.com/REDCROSS16',
    py_modules = ['vsearch'],
)